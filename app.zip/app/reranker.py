# app/reranker.py
from typing import List, Tuple, Dict
from sentence_transformers import CrossEncoder

class Reranker:
    def __init__(self, model_name: str):
        # model đầu ra điểm càng cao càng liên quan
        self.model = CrossEncoder(model_name)

    def rerank(
        self,
        claim: str,
        candidates: List[Tuple[int, float]],    # [(chunk_id, base_score)]
        chunk_map: Dict[int, Dict],
        topk: int = 20
    ) -> List[Tuple[int, float, float]]:
        """
        Trả [(chunk_id, base_score, rerank_score)] theo thứ tự điểm reranker giảm dần.
        """
        # chuẩn bị cặp (claim, chunk_text)
        pairs, ids, base_scores = [], [], []
        for cid, sc in candidates[:topk]:
            text = (chunk_map.get(cid) or {}).get("text") or ""
            pairs.append((claim, text))
            ids.append(cid)
            base_scores.append(sc)

        if not pairs:
            return []

        scores = self.model.predict(pairs)  # numpy array shape (n,)
        # trả về list kèm điểm reranker
        ranked = list(zip(ids, base_scores, scores.tolist()))
        # sắp theo rerank_score giảm dần
        ranked.sort(key=lambda x: x[2], reverse=True)
        return ranked
