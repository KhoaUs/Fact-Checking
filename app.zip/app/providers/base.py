# app/providers/base.py
from abc import ABC, abstractmethod
from typing import Iterable, Dict

class Provider(ABC):
    """
    Base class cho mọi Provider (RSSProvider, JSONAPIProvider, ...).
    Mục tiêu: chuẩn hóa output để ingest pipeline có thể xử lý thống nhất.
    """

    @abstractmethod
    def fetch(self) -> Iterable[Dict]:
        """
        Trả về một danh sách các record dạng dict với schema tối thiểu:
        {
            "url": str,            # link bài gốc
            "domain": str,         # domain (vd: vnexpress.net)
            "title": str,          # tiêu đề
            "text": str,           # nội dung text (nếu có)
            "published_at": str,   # ngày xuất bản ISO hoặc None
            "lang": str,           # mã ngôn ngữ (vd: "vi")
            "tier": int            # độ tin cậy (1=chính thống, 2=khá tin cậy, 3=mặc định)
        }
        """
        ...
