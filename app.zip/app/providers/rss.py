# app/providers/rss.py
import feedparser
from tldextract import extract as tld_extract
from typing import Iterable, Dict, Optional

def get_domain(u: str) -> str:
    e = tld_extract(u)
    return ".".join([p for p in [e.subdomain, e.domain, e.suffix] if p])

class RSSProvider:
    def __init__(self, url: str, tier: int = 3):
        self.url = url
        self.tier = tier

    def fetch(self) -> Iterable[Dict]:
        feed = feedparser.parse(self.url)
        for e in feed.entries:
            url = e.get("link")
            if not url: continue
            yield {
                "url": url,
                "domain": get_domain(url),
                "title": e.get("title", ""),
                "text": e.get("summary", "") or "",  # một số RSS chỉ có summary
                "published_at": e.get("published") or e.get("updated"),
                "lang": getattr(feed.feed, "language", "vi") or "vi",
                "tier": self.tier
            }
