# app/providers/jsonapi.py
import requests
from tldextract import extract as tld_extract
from typing import Iterable, Dict
from pydantic import BaseModel
from datetime import datetime

def get_domain(u: str) -> str:
    e = tld_extract(u)
    return ".".join([p for p in [e.subdomain, e.domain, e.suffix] if p])

class JSONMapping(BaseModel):
    items: str                        # ví dụ "data.items"
    fields: Dict[str, str]            # {"url":"link","title":"title",...}

def deep_get(obj, path: str):
    cur = obj
    for p in path.split("."):
        if isinstance(cur, list):
            try: p = int(p)
            except: return None
        cur = cur.get(p) if isinstance(cur, dict) else (cur[p] if isinstance(cur, list) and 0 <= p < len(cur) else None)
        if cur is None: return None
    return cur

class JSONAPIProvider:
    def __init__(self, url: str, mapping: JSONMapping, tier: int = 3, headers: dict | None = None):
        self.url = url
        self.mapping = mapping
        self.tier = tier
        self.headers = headers or {}

    def fetch(self) -> Iterable[Dict]:
        r = requests.get(self.url, headers=self.headers, timeout=20)
        r.raise_for_status()
        data = r.json()
        items = deep_get(data, self.mapping.items) or []
        for it in items:
            url = deep_get(it, self.mapping.fields.get("url",""))
            if not url: continue
            yield {
                "url": url,
                "domain": get_domain(url),
                "title": deep_get(it, self.mapping.fields.get("title","")) or "",
                "text":  deep_get(it, self.mapping.fields.get("text","")) or "",
                "published_at": deep_get(it, self.mapping.fields.get("published_at","")),
                "lang": deep_get(it, self.mapping.fields.get("lang","")) or "vi",
                "tier": self.tier
            }
