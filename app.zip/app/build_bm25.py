# app/build_bm25.py
from pathlib import Path
import yaml
from whoosh.index import create_in, open_dir
from whoosh.fields import Schema, TEXT, ID, STORED
from whoosh.analysis import StemmingAnalyzer
from sqlalchemy import create_engine, text as sql
from whoosh.writing import AsyncWriter

def get_cfg():
    return yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

def load_chunks(db_path: str):
    eng = create_engine(f"sqlite:///{db_path}")
    with eng.connect() as conn:
        rows = conn.execute(sql("""
            SELECT chunks.id as chunk_id, chunks.text as text,
                   docs.id as doc_id, docs.title as title, docs.domain as domain
            FROM chunks JOIN docs ON chunks.doc_id = docs.id
        """)).mappings().all()
    return rows

def ensure_index_dir(dirpath: str, schema):
    p = Path(dirpath); p.mkdir(parents=True, exist_ok=True)
    if any(p.iterdir()):
        return open_dir(dirpath)
    return create_in(dirpath, schema)

def main():
    cfg = get_cfg()
    whoosh_dir = cfg["paths"].get("whoosh_dir", "data/whoosh_index")
    db_path    = cfg["paths"]["db_path"]

    print("📥 Loading chunks from DB...")
    rows = load_chunks(db_path)
    print(f"→ {len(rows)} chunks")

    schema = Schema(
        chunk_id=ID(stored=True, unique=True),
        doc_id=ID(stored=True),
        domain=ID(stored=True),
        title=TEXT(stored=True, analyzer=StemmingAnalyzer()),
        text=TEXT(stored=True, analyzer=StemmingAnalyzer())
    )
    ix = ensure_index_dir(whoosh_dir, schema)

    print("🧱 Building BM25 index...")
    writer = AsyncWriter(ix)
    for r in rows:
        writer.update_document(
            chunk_id=str(r["chunk_id"]),
            doc_id=str(r["doc_id"]),
            domain=str(r["domain"] or ""),
            title=r["title"] or "",
            text=r["text"] or ""
        )
    writer.commit()
    print(f"✅ Done. Index at: {whoosh_dir}")

if __name__ == "__main__":
    main()
