import re, unicodedata
from dateutil import parser as dateparser

SENT_SPLIT = re.compile(r"(?<=[\.\!\?])\s+(?=[A-ZÀ-Ỵ])")

def normalize_text(t: str) -> str:
    t = unicodedata.normalize("NFC", t)
    t = t.replace("\u00A0", " ").strip()
    return re.sub(r"\s+", " ", t)

def split_sentences(text: str) -> list[str]:
    return [s.strip() for s in SENT_SPLIT.split(text) if s.strip()]

def to_datetime_or_none(s: str | None):
    if not s: return None
    try: return dateparser.parse(s)
    except Exception: return None
