# app/models/phobert_loader.py
from pathlib import Path
import torch, torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForSequenceClassification

class PhoBERTClassifier:
    def __init__(self, hub_id_or_dir: str, use_fast=False, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tok = AutoTokenizer.from_pretrained(hub_id_or_dir, use_fast=use_fast)
        self.model = AutoModelForSequenceClassification.from_pretrained(hub_id_or_dir)
        self.model.to(self.device).eval()
        # id2label fallback nếu thiếu
        cfg = self.model.config
        self.id2label = {int(k): v for k, v in getattr(cfg, "id2label", {}).items()} or {0:"REAL",1:"FAKE",2:"NEI"}
        self.label2id = {v:k for k,v in self.id2label.items()}
        self.fake_id = self.label2id.get("FAKE", 1)

    @torch.inference_mode()
    def predict(self, claim: str, evidences: list[str] | None = None, fake_threshold: float = 0.5):
        evidences = evidences or []
        text_b = " </s> ".join([e.strip() for e in evidences if e and str(e).strip()])
        enc = self.tok(claim.strip(), text_b, return_tensors="pt", truncation=True, max_length=512)
        enc = {k: v.to(self.device) for k,v in enc.items()}
        logits = self.model(**enc).logits
        probs = F.softmax(logits, dim=-1).squeeze(0).tolist()
        pred = int(max(range(len(probs)), key=lambda i: probs[i]))
        # ưu tiên FAKE nếu vượt ngưỡng
        if probs[self.fake_id] >= float(fake_threshold):
            pred = self.fake_id
        return self.id2label[pred], float(probs[pred]), {self.id2label[i]: float(probs[i]) for i in range(len(probs))}
