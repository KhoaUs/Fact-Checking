# app/ingest_api.py
import argparse, yaml, hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict

from .metadata import init_db, Doc, Chunk
from .storage import ObjectStore
from .utils_text import to_datetime_or_none
from .cleaner import clean_doc
from .chunker import make_chunks

from .providers.base import Provider
from .providers.rss import RSSProvider
from .providers.jsonapi import JSONAPIProvider, JSONMapping

def sha1(s: str) -> str:
    import hashlib
    return hashlib.sha1(s.encode("utf-8")).hexdigest()

def build_provider(src: Dict) -> Provider:
    ptype = src["provider"]
    if ptype == "rss":
        return RSSProvider(url=src["url"], tier=src.get("tier",3))
    elif ptype == "json":
        mapping = JSONMapping(**src["json_mapping"])
        headers = src.get("headers") or {}
        return JSONAPIProvider(url=src["url"], mapping=mapping, tier=src.get("tier",3), headers=headers)
    else:
        raise ValueError(f"Unknown provider: {ptype}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--seeds", default="seeds_api.yaml")
    ap.add_argument("--limit_per_source", type=int, default=50)
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    seeds = yaml.safe_load(Path(args.seeds).read_text(encoding="utf-8"))["sources"]

    Path(cfg["paths"]["data_dir"]).mkdir(parents=True, exist_ok=True)
    Path(cfg["paths"]["objects_dir"]).mkdir(parents=True, exist_ok=True)
    Path(cfg["paths"]["db_path"]).parent.mkdir(parents=True, exist_ok=True)

    Session = init_db(cfg["paths"]["db_path"]); 
    sess = Session()
    store = ObjectStore(cfg["paths"]["objects_dir"])

    total_docs = total_chunks = 0
    for src in seeds:
        provider = build_provider(src)
        print(f"🔌 Fetching: {src['name']} ({src['provider']})")
        n, n_chunks = 0, 0
        for item in provider.fetch():
            if n >= args.limit_per_source: break
            # clean/normalize cơ bản
            d = clean_doc(item)
            if not d.get("title") and not d.get("text"): continue

            # lưu object
            obj_path = store.put_json(d["url"], {
                "url": d["url"], "domain": d["domain"], "title": d["title"],
                "text": d.get("text",""), "published_at": d.get("published_at"), "lang": d.get("lang","vi")
            })

            # upsert Doc
            exists = sess.query(Doc).filter_by(url=d["url"]).first()
            if exists:
                doc_id = exists.id
            else:
                ndoc = Doc(url=d["url"], domain=d["domain"], title=d["title"],
                           published_at=to_datetime_or_none(d.get("published_at")),
                           path_obj=obj_path, lang=d.get("lang","vi"), hash=sha1((d.get("text") or "")[:512]))
                sess.add(ndoc); sess.flush()
                doc_id = ndoc.id
                total_docs += 1; n += 1

            # chunking từ text nếu có
            text = d.get("text") or ""
            if text.strip():
                # 🔹 tránh ghi trùng: nếu doc đã có chunks thì bỏ qua
                existed = sess.query(Chunk.id).filter_by(doc_id=doc_id).first()
                if existed:
                    continue  # đã có, không chunk lại
                chunks = make_chunks(text)
                for idx, para in enumerate(chunks):
                    sess.add(Chunk(doc_id=doc_id, idx=idx, text=para,
                                   published_at=to_datetime_or_none(d.get("published_at")),
                                   lang=d.get("lang","vi")))
                    total_chunks += 1; n_chunks += 1

        sess.commit()
        print(f"  → Added docs: {n}, chunks: {n_chunks}")

    print(f"✅ Total docs: {total_docs}, chunks: {total_chunks}")
    print(f"🗃️  DB: {cfg['paths']['db_path']} | 📁 Objects: {cfg['paths']['objects_dir']}")

if __name__ == "__main__":
    main()
