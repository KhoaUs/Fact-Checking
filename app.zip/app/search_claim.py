# app/search_claim.py
import argparse, yaml
from pathlib import Path
from whoosh.index import open_dir
from whoosh.qparser import MultifieldParser

def get_cfg():
    return yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

def search_claim(query: str, topk: int = 5):
    cfg = get_cfg()
    whoosh_dir = cfg["paths"].get("whoosh_dir", "data/whoosh_index")
    ix = open_dir(whoosh_dir)

    with ix.searcher() as s:
        qp = MultifieldParser(["title","text"], schema=ix.schema)
        q = qp.parse(query)
        hits = s.search(q, limit=topk)
        results = []
        for h in hits:
            src = {
                "score": float(h.score),
                "chunk_id": h["chunk_id"],
                "doc_id": h["doc_id"],
                "domain": h["domain"],
                "title": h["title"],
                "text": h["text"][:300] + ("..." if len(h["text"])>300 else "")
            }
            results.append(src)
        return results

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--q", required=True, help="Câu claim cần tìm evidence")
    ap.add_argument("--k", type=int, default=5)
    args = ap.parse_args()

    rows = search_claim(args.q, args.k)
    print(f"🔎 Top {len(rows)} kết quả cho: {args.q}\n")
    for i, r in enumerate(rows, 1):
        print(f"{i:>2}. score={r['score']:.2f} | {r['domain']}")
        print(f"    {r['title']}")
        print(f"    {r['text']}\n")
