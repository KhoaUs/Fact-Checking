import argparse, yaml
from pathlib import Path
from .kb_adapter import KB
from .models.phobert_loader import PhoBERTClassifier

def load_cfg():
    return yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

def run_verify(claim: str, m: int = 3, fake_threshold: float = 0.5):
    cfg = load_cfg()
    kb = KB()
    ev = kb.top_evidence(claim, m=m)

    # gom text evidence
    ev_texts = [e.get("text","") or "" for e in ev]
    hub_id = cfg["models"].get("phobert_hub_id") or cfg["models"].get("phobert_dir")
    clf = PhoBERTClassifier(hub_id, use_fast=False)

    label, conf, prob_dict = clf.predict(claim, ev_texts, fake_threshold=fake_threshold)

    print(f"CLAIM: {claim}")
    print(f"VERDICT: {label} (conf={conf:.2f})")
    print("PROBS:", prob_dict, "\n")

    print("EVIDENCE:")
    for i, e in enumerate(ev, 1):
        print(f"{i}. {e['domain']} | {e.get('published_at')}")
        print(f"   {e['title']}")
        t = e.get('text') or ''
        print(f"   {t[:240]}{'...' if len(t)>240 else ''}")
        print(f"   URL: {e['url']}\n")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--q", required=True, help="Claim")
    ap.add_argument("--m", type=int, default=3, help="Số evidence tối đa")
    ap.add_argument("--fake_threshold", type=float, default=0.5)
    args = ap.parse_args()
    run_verify(args.q, m=args.m, fake_threshold=args.fake_threshold)
