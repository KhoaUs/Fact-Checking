# app/build_vector.py
from pathlib import Path
import yaml, numpy as np
from sqlalchemy import create_engine, text as sql
from sentence_transformers import SentenceTransformer
import faiss

def get_cfg():
    return yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

def load_chunks(db_path: str):
    eng = create_engine(f"sqlite:///{db_path}")
    with eng.connect() as conn:
        rows = conn.execute(sql("""
          SELECT chunks.id AS chunk_id, chunks.text AS text
          FROM chunks ORDER BY chunks.id
        """)).mappings().all()
    return rows

def main():
    cfg = get_cfg()
    faiss_dir = Path(cfg["paths"]["faiss_dir"]); faiss_dir.mkdir(parents=True, exist_ok=True)
    db_path = cfg["paths"]["db_path"]
    model_name = cfg["models"]["embed_model"]

    print("📥 Loading chunks...")
    rows = load_chunks(db_path)
    texts = [r["text"] or "" for r in rows]
    ids   = np.array([int(r["chunk_id"]) for r in rows], dtype=np.int64)
    print(f"→ {len(texts)} chunks")

    print(f"🧠 Loading embedding model: {model_name}")
    model = SentenceTransformer(model_name)

    # E5 khuyến nghị thêm prefix "query: " và "passage: "
    def encode_passages(batch):
        return model.encode(["passage: " + t for t in batch], batch_size=64, show_progress_bar=True, convert_to_numpy=True, normalize_embeddings=True)

    print("🧮 Encoding embeddings...")
    embs = encode_passages(texts).astype("float32")  # shape (N, d)

    print("💾 Saving embeddings + id map...")
    np.save(faiss_dir / "embeddings.npy", embs)
    np.save(faiss_dir / "chunk_ids.npy", ids)   # map từ FAISS idx -> chunk_id

    d = embs.shape[1]
    index = faiss.IndexFlatIP(d)  # cosine nếu đã normalize
    index.add(embs)
    faiss.write_index(index, str(faiss_dir / "index.faiss"))
    print(f"✅ FAISS built at {faiss_dir}")

if __name__ == "__main__":
    main()
