import json, hashlib
from pathlib import Path

class ObjectStore:
    def __init__(self, base: str):
        self.base = Path(base); self.base.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def sha1(s: str) -> str:
        return hashlib.sha1(s.encode("utf-8")).hexdigest()

    def put_json(self, key_hint: str, obj: dict) -> str:
        key = self.sha1(key_hint) + ".json"
        path = self.base / key
        path.write_text(json.dumps(obj, ensure_ascii=False), encoding="utf-8")
        return str(path)
