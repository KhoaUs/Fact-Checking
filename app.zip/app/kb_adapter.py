# app/kb_adapter.py
import yaml, numpy as np
from pathlib import Path
from whoosh.index import open_dir
from whoosh.qparser import MultifieldParser
from sqlalchemy import create_engine, text as sql
from sentence_transformers import SentenceTransformer
import faiss

from .reranker import Reranker
from .fusion import fuse_scores

class KB:
    def __init__(self, cfg_path="config.yaml"):
        self.cfg = yaml.safe_load(Path(cfg_path).read_text(encoding="utf-8"))

        # BM25 (Whoosh)
        self.ix = open_dir(self.cfg["paths"]["whoosh_dir"])

        # FAISS (vector)
        fdir = Path(self.cfg["paths"]["faiss_dir"])
        self.faiss_index = faiss.read_index(str(fdir / "index.faiss"))
        self.ids_map = np.load(fdir / "chunk_ids.npy")

        # Metadata map: chunk_id -> {text, title, url, domain, published_at, ...}
        eng = create_engine(f"sqlite:///{self.cfg['paths']['db_path']}")
        with eng.connect() as c:
            rows = c.execute(sql("""
                SELECT chunks.id AS chunk_id, chunks.text AS text,
                       docs.id AS doc_id, docs.title AS title, docs.url AS url, docs.domain AS domain,
                       docs.published_at AS published_at
                FROM chunks JOIN docs ON chunks.doc_id = docs.id
            """)).mappings().all()
        self.cmap = {int(r["chunk_id"]): dict(r) for r in rows}

        # Embedding model (query encoder)
        self.emodel = SentenceTransformer(self.cfg["models"]["embed_model"])

        # Reranker (có thể thiếu trong config → fallback stub)
        rer_name = self.cfg.get("models", {}).get("reranker", None)
        if rer_name:
            self.reranker = Reranker(rer_name)
            self.has_reranker = True
        else:
            self.reranker = self._stub_reranker()
            self.has_reranker = False

    def _stub_reranker(self):
        class _Stub:
            def rerank(self, claim, candidates, chunk_map, topk=20):
                # Trả về [(cid, base_sc, rer_sc=0.0)] giữ nguyên thứ tự
                return [(cid, base_sc, 0.0) for cid, base_sc in candidates[:topk]]
        return _Stub()

    def _bm25(self, query, topk):
        with self.ix.searcher() as s:
            qp = MultifieldParser(["title", "text"], schema=self.ix.schema)
            q = qp.parse(query)
            hits = s.search(q, limit=topk)
            return [(int(h["chunk_id"]), float(h.score)) for h in hits]

    def _vec(self, query, topk):
        qvec = self.emodel.encode(
            ["query: " + query],
            convert_to_numpy=True, normalize_embeddings=True
        ).astype("float32")
        scores, idxs = self.faiss_index.search(qvec, topk)
        out = []
        for i, sc in zip(idxs[0], scores[0]):
            if i == -1:
                continue
            out.append((int(self.ids_map[i]), float(sc)))
        return out

    def _fuse_linear(self, bm25, vec):
        w_bm25 = float(self.cfg["fusion"]["w_bm25"])
        w_vec = float(self.cfg["fusion"]["w_vec"])
        scores = {}
        for cid, s in bm25:
            scores[cid] = scores.get(cid, 0.0) + w_bm25 * s
        for cid, s in vec:
            scores[cid] = scores.get(cid, 0.0) + w_vec * s
        return sorted(scores.items(), key=lambda x: x[1], reverse=True)

    def top_evidence(self, claim, m=None):
        m = m or self.cfg["retrieval"]["evidence_m"]

        # 1) Lấy ứng viên từ BM25 & Vector
        bm = self._bm25(claim, self.cfg["retrieval"]["bm25_topk"])
        ve = self._vec(claim, self.cfg["retrieval"]["vec_topk"])
        vec_map = {cid: sc for cid, sc in ve}  # dùng fallback khi không có reranker

        # 2) Fuse tuyến tính (trước rerank)
        fused = self._fuse_linear(bm, ve)  # [(cid, base_sc)]

        # 3) Rerank (nếu có)
        rerank_top = self.cfg["retrieval"]["rerank_topk"]
        reranked = self.reranker.rerank(claim, fused, self.cmap, rerank_top)
        # reranked: [(cid, base_sc, rer_sc)] — stub thì rer_sc = 0.0

        # 4) Lọc theo ngưỡng liên quan
        th = self.cfg.get("thresholds", {})
        min_rer = float(th.get("min_rerank", 0.25))
        min_vec = float(th.get("min_vec", 0.25))
        keep_at_least = int(th.get("keep_at_least", 1))

        filtered = []
        for cid, base_sc, rer_sc in reranked:
            ok = (rer_sc >= min_rer) if self.has_reranker else (vec_map.get(cid, 0.0) >= min_vec)
            if ok:
                filtered.append((cid, base_sc, rer_sc))

        if not filtered and reranked:
            filtered = reranked[:keep_at_least]

        # 5) Tính điểm cuối (fusion cuối: trust + staleness + w_rer)
        final = []
        for cid, base_sc, rer_sc in filtered:
            rec = self.cmap.get(cid, {})
            final_sc = fuse_scores(
                base_score=base_sc,
                rerank_score=rer_sc,
                domain=rec.get("domain", ""),
                published_at_iso=rec.get("published_at"),
                cfg_fusion=self.cfg["fusion"]
            )
            final.append((cid, final_sc, base_sc, rer_sc))

        final.sort(key=lambda x: x[1], reverse=True)

        # 6) Cắt tối đa m
        out = []
        for cid, sc, base_sc, rer_sc in final[:m]:
            r = self.cmap.get(cid, {})
            out.append({
                "chunk_id": cid,
                "score": sc,
                "base_score": base_sc,
                "rerank_score": rer_sc,
                "text": r.get("text"),
                "title": r.get("title"),
                "url": r.get("url"),
                "domain": r.get("domain"),
                "published_at": r.get("published_at"),
            })
        return out
