# app/ingest_wiki.py
import os, re, json
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import yaml

# NOTE: chỉnh import cho khớp model DB của bạn
from app.metadata import Base, Doc, Chunk  # Doc(url,domain,title,published_at,path_obj,lang), Chunk(doc_id,idx,text,lang, ...)

CFG = yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

EXTRACT_DIR = Path("data/wiki_extracted")     # thư mục đầu ra của WikiExtractor (tùy bạn)
DOMAIN      = "vi.wikipedia.org"
LANG        = "vi"
TIER        = 1

# Bỏ các namespace không phải article chính và trang "định hướng"
# (WikiExtractor đã loại nhiều namespace, nhưng ta filter thêm theo title để chắc ăn)
BAD_TITLE = re.compile(r"(^Thể loại:|^Tập tin:|^Tập\ tin:|^Wikipedia:|^Bản mẫu:|^Bản\ mẫu:|^Portal:|^Đặc biệt:|định hướng)", re.IGNORECASE)

def normalize_text(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s

def simple_chunks(text: str, min_words=80, max_words=180):
    """Chunk theo số từ (ổn với wiki, không lệ thuộc sections)."""
    words = text.split()
    out, cur = [], []
    for w in words:
        cur.append(w)
        if len(cur) >= max_words:
            out.append(" ".join(cur)); cur = []
    if cur:
        if len(cur) < min_words and out:
            out[-1] = out[-1] + " " + " ".join(cur)
        else:
            out.append(" ".join(cur))
    return [c for c in out if len(c.split()) >= min_words]

def jsonl_iter(path: Path):
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except Exception:
                continue

def main():
    # --- DB session ---
    eng = create_engine(f"sqlite:///{CFG['paths']['db_path']}")
    Session = sessionmaker(bind=eng)
    sess = Session()

    total_docs = total_chunks = skipped_short = skipped_bad = 0

    for root, _, files in os.walk(EXTRACT_DIR):
        for fn in files:
            # if not fn.endswith(".json"):  # WikiExtractor --json tạo nhiều .json
            #     continue
            p = Path(root) / fn
            for rec in jsonl_iter(p):
                # kỳ vọng các field phổ biến từ WikiExtractor --json:
                # {"id": "...", "url": "https://vi.wikipedia.org/wiki/...", "title": "...", "text": "..."}
                title = normalize_text(rec.get("title", ""))
                if not title or BAD_TITLE.search(title):
                    skipped_bad += 1
                    continue

                url = rec.get("url") or (f"https://{DOMAIN}/wiki/" + title.replace(" ", "_"))
                text = normalize_text(rec.get("text", ""))

                if not text or len(text.split()) < 80:
                    skipped_short += 1
                    continue

                # tránh trùng theo URL
                existed = sess.query(Doc).filter_by(url=url).first()
                if existed:
                    continue

                # tạo Doc
                ndoc = Doc(
                    url=url,
                    domain=DOMAIN,
                    title=title,
                    published_at=None,   # wiki không có ngày xuất bản
                    path_obj=None,
                    lang=LANG
                )
                sess.add(ndoc); sess.flush()
                total_docs += 1

                # chunk & ghi
                chunks = simple_chunks(text, min_words=80, max_words=180)
                for idx, para in enumerate(chunks):
                    sess.add(Chunk(
                        doc_id=ndoc.id,
                        idx=idx,
                        text=para,
                        published_at=None,
                        lang=LANG
                    ))
                    total_chunks += 1

                # commit mỗi ~500 bản ghi để đỡ tốn RAM
                if (total_docs + total_chunks) % 500 == 0:
                    sess.commit()

    sess.commit()
    print(f"✅ Wiki ingest done. docs={total_docs}, chunks={total_chunks}, "
          f"skipped_short={skipped_short}, skipped_bad={skipped_bad}")

if __name__ == "__main__":
    main()
