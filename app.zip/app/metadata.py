from pathlib import Path
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.sql import func
Base = declarative_base()

class Doc(Base):
    __tablename__ = "docs"
    id = Column(Integer, primary_key=True)
    url = Column(Text, unique=True, nullable=False)
    domain = Column(String, index=True, nullable=False)
    title = Column(Text)
    published_at = Column(DateTime)
    path_obj = Column(Text)            # đường dẫn file json lưu nội dung sạch
    lang = Column(String, default="vi")
    hash = Column(String, index=True)  # để chống trùng (tùy dùng sau)
    created_at = Column(DateTime, server_default=func.current_timestamp())

class Chunk(Base):
    __tablename__ = "chunks"
    id = Column(Integer, primary_key=True)
    doc_id = Column(Integer, ForeignKey("docs.id", ondelete="CASCADE"), index=True)
    idx = Column(Integer)              # thứ tự trong doc
    text = Column(Text)
    start_char = Column(Integer)
    end_char = Column(Integer)
    published_at = Column(DateTime)
    lang = Column(String, default="vi")
    __table_args__ = (UniqueConstraint('doc_id','idx', name='uq_doc_idx'),)

def init_db(db_path: str):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)   
    eng = create_engine(f"sqlite:///{db_path}")
    Base.metadata.create_all(eng)
    return sessionmaker(bind=eng, autoflush=False, autocommit=False)
