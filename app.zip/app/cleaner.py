from .utils_text import normalize_text, to_datetime_or_none
from bs4 import BeautifulSoup

def strip_html(s: str) -> str:
    try:
        return BeautifulSoup(s, "html.parser").get_text(" ", strip=True)
    except Exception:
        return s

def clean_doc(doc: dict) -> dict:
    title = normalize_text(doc.get("title",""))
    text  = normalize_text(doc.get("text",""))
    if "<" in text and ">" in text:   # có dấu hiệu HTML
        text = strip_html(text)
    dt = to_datetime_or_none(doc.get("published_at") or doc.get("date"))
    return {
        **doc,
        "title": title,
        "text": text,
        "published_at": dt.isoformat() if dt else None
    }
