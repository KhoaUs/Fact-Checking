# app/fusion.py
import math
from datetime import datetime
from typing import Optional, Dict

def days_since(iso: Optional[str]) -> Optional[int]:
    if not iso:
        return None
    try:
        # chấp nhận 'YYYY-MM-DD' hoặc ISO có 'T'
        s = iso.replace("Z","")
        if "T" in s:
            return (datetime.utcnow() - datetime.fromisoformat(s)).days
        return (datetime.utcnow() - datetime.fromisoformat(s + "T00:00:00")).days
    except Exception:
        return None

def staleness_penalty(days: Optional[int], half_life_days: int) -> float:
    if days is None:
        return 0.0
    # 1 - exp(-days / half_life) ∈ [0,1) — càng cũ càng bị trừ nhiều
    return 1.0 - math.exp(-float(days) / float(half_life_days))

def domain_trust(domain: str, table: Dict[str, float], default_trust: float) -> float:
    if not domain:
        return default_trust
    return float(table.get(domain, default_trust))

def fuse_scores(
    base_score: float,
    rerank_score: float,
    domain: str,
    published_at_iso: str | None,
    cfg_fusion: Dict
) -> float:
    w_bm25 = cfg_fusion.get("w_bm25", 0.45)
    w_vec  = cfg_fusion.get("w_vec", 0.35)
    w_rer  = cfg_fusion.get("w_rer", 0.20)
    # base_score ở đây đã là tổng hợp (w_bm25*bm25 + w_vec*vec) trước rerank
    # ta cộng thêm w_rer*rerank_score và hiệu chỉnh trust/time
    trust_tbl = cfg_fusion.get("trust", {})
    default_trust = cfg_fusion.get("default_trust", 0.7)
    half_life = cfg_fusion.get("half_life_days", 365)

    trust = domain_trust(domain, trust_tbl, default_trust)
    age_d = days_since(published_at_iso)
    age_pen = staleness_penalty(age_d, half_life)

    score = base_score + w_rer * rerank_score
    # thêm hiệu chỉnh nhẹ
    score += 0.06 * trust
    score -= 0.04 * age_pen
    return score
