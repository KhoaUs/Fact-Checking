from .utils_text import split_sentences

def make_chunks(text: str, min_sent=2, max_sent=4, min_words=20):
    sents = split_sentences(text)
    out, cur = [], []
    for s in sents:
        cur.append(s)
        if len(cur) >= max_sent:
            out.append(" ".join(cur)); cur=[]
    if cur:
        if len(cur) < min_sent and out:
            out[-1] = out[-1] + " " + " ".join(cur)
        else:
            out.append(" ".join(cur))
    return [c for c in out if len(c.split()) >= min_words]
