# app/hybrid_search.py
import argparse, yaml, numpy as np
from pathlib import Path
from whoosh.index import open_dir
from whoosh.qparser import MultifieldParser
from sqlalchemy import create_engine, text as sql
from sentence_transformers import SentenceTransformer
import faiss

def get_cfg():
    return yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))

def load_meta(db_path: str):
    eng = create_engine(f"sqlite:///{db_path}")
    with eng.connect() as conn:
        chunks = conn.execute(sql("""
          SELECT chunks.id AS chunk_id, chunks.text AS text,
                 docs.id AS doc_id, docs.title AS title, docs.url AS url, docs.domain AS domain,
                 docs.published_at AS published_at
          FROM chunks JOIN docs ON chunks.doc_id = docs.id
        """)).mappings().all()
    # map chunk_id -> record
    c_map = {int(r["chunk_id"]): dict(r) for r in chunks}
    return c_map

def bm25_search(ix, query, topk):
    with ix.searcher() as s:
        qp = MultifieldParser(["title","text"], schema=ix.schema)
        q = qp.parse(query)
        hits = s.search(q, limit=topk)
        return [(int(h["chunk_id"]), float(h.score)) for h in hits]

def vec_search(index, ids_map, emb_model, query, topk):
    qvec = emb_model.encode(["query: " + query], convert_to_numpy=True, normalize_embeddings=True).astype("float32")
    scores, idxs = index.search(qvec, topk)
    out = []
    for i, sc in zip(idxs[0], scores[0]):
        if i == -1: continue
        out.append((int(ids_map[i]), float(sc)))  # map FAISS idx -> chunk_id
    return out

def fuse(bm25, vec, w_bm25=0.5, w_vec=0.5):
    score = {}
    for cid, s in bm25: score[cid] = score.get(cid, 0.0) + w_bm25*s
    for cid, s in vec:  score[cid] = score.get(cid, 0.0) + w_vec*s
    return sorted(score.items(), key=lambda x: x[1], reverse=True)

def rerank_stub(claim, candidates, chunk_map, topk):
    # TODO: thay bằng cross-encoder (bge-reranker m3 / xlm-r) sau
    return candidates[:topk]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--q", required=True, help="Claim cần tìm")
    ap.add_argument("--k", type=int, default=5)
    args = ap.parse_args()

    cfg = get_cfg()
    # load BM25
    ix = open_dir(cfg["paths"]["whoosh_dir"])
    # load FAISS
    faiss_dir = Path(cfg["paths"]["faiss_dir"])
    index = faiss.read_index(str(faiss_dir / "index.faiss"))
    ids_map = np.load(faiss_dir / "chunk_ids.npy")   # array index -> chunk_id
    # load meta
    c_map = load_meta(cfg["paths"]["db_path"])
    # embed model
    model = SentenceTransformer(cfg["models"]["embed_model"])

    bm = bm25_search(ix, args.q, cfg["retrieval"]["bm25_topk"])
    ve = vec_search(index, ids_map, model, args.q, cfg["retrieval"]["vec_topk"])
    fused = fuse(bm, ve, cfg["fusion"]["w_bm25"], cfg["fusion"]["w_vec"])
    reranked = rerank_stub(args.q, fused, c_map, cfg["retrieval"]["rerank_topk"])

    topm = reranked[:cfg["retrieval"]["evidence_m"]]
    print(f"🔎 Query: {args.q}")
    for rank, (cid, sc) in enumerate(topm, 1):
        r = c_map.get(cid, {})
        text = (r.get("text","")[:240] + "...") if r.get("text") and len(r["text"])>240 else r.get("text","")
        print(f"\n{rank}. score={sc:.4f} | {r.get('domain')} | {r.get('published_at')}")
        print(f"   {r.get('title')}")
        print(f"   {text}")
        print(f"   URL: {r.get('url')}")

if __name__ == "__main__":
    main()
